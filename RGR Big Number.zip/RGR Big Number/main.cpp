#include <iostream>
#include "BigNumber.h"
#include "LexicalAnalyzer.h"



int main()
{


   TableToken tokens;

   tokens.Lexical_Analyzer("input50.txt");

   tokens.Print();

   cout << endl;
   
   stack<variant<int, BigNumber>> stack_int;

   //tokens.Interpreter(stack_int);



   

   return 0;
}